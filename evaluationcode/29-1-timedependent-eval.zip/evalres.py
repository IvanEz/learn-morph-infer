kevin@unilaptop ~/D/u/b/e/timedependent> python3 eval_vis.py --parapros 16
Namespace(parapros=16)
acceptable: 1575 (19.6875%), ok: 819 (10.237499999999999%), good: 441 (5.5125%), amazing: 182 (2.275%)

